CUBE v1.2
Feb 4, 2013
By Amon Ge

A short but sweet puzzle platformer.
Control cube, a curious little box, in its quest for freedom!
Complete all 16 brain twisting puzzles and you may be in for a treat.


THIS WAS MADE FOR:
	MS. BEER
	AND ICS4U
AT: 
	NEWMARKET HIGH SCHOOL

A SUMMATIVE ULTIMATUM FINATUM OPUS
LAUNCH CUBE.EXE TO BEGIN


Created: March 17, 2012

Version History:
       1.2 - Feb  4 2013 - added version number to bottom of main menu
                         - changed save file to %appdata% path
                         - removed unused images (empty painter, storer block)
                         - minor formatting

       1.1 - Jun 24 2012 - fixed sometimes flash of white when changing levels

       1.0 - Jun 19 2012 - finished all levels